import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll, { passive: true });
    setIsScrolled(window.scrollY > 10);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => { setIsMobileMenuOpen(false); }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Domestic', path: '/trips?type=domestic' },
    { name: 'International', path: '/trips?type=international' },
    { name: 'Contact', path: '/contact' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Testimonials', path: '/testimonials' },
  ];

  const isHome = location.pathname === '/';
  const transparent = isHome && !isScrolled;

  // active check — handle query-param links too
  const isActive = (path) => {
    const [p, q] = path.split('?');
    if (q) {
      return location.pathname === p && location.search === `?${q}`;
    }
    return location.pathname === path;
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={
        transparent
          ? { background: 'linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0) 100%)' }
          : { background: '#ffffff', borderBottom: '1px solid #EEEEEE', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }
      }
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-[76px]">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 flex-shrink-0">
            <div className="flex items-center gap-3">
              <img
                src="/trek_premi.png"
                alt="Trek Premi"
                className="h-12 w-12 md:h-12 md:w-12 object-contain rounded-full bg-white p-1"
              />
              <div className="leading-tight">
                <div className={`text-lg md:text-base font-bold font-poppins tracking-tight ${transparent ? 'text-white' : 'text-[#111111]'}`}>
                  Trek Premi
                </div>
                <div className="text-xs md:text-[11px] text-[#F5B301] tracking-wide">Discover the world with us</div>
              </div>
            </div>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-5">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative text-sm font-medium transition-colors duration-300 whitespace-nowrap ${
                  isActive(link.path)
                    ? 'text-[#F5B301]'
                    : transparent
                    ? 'text-white/85 hover:text-white'
                    : 'text-[#444] hover:text-[#111]'
                }`}
              >
                {link.name}
                {isActive(link.path) && (
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-[#F5B301] rounded-full" />
                )}
              </Link>
            ))}
          </div>

          {/* Book Now */}
          <Link
            to="/trips"
            className="hidden md:inline-flex items-center bg-[#F5B301] text-[#111111] font-semibold px-5 py-2 rounded-full text-sm hover:bg-[#E5A100] hover:shadow-[0_4px_20px_rgba(245,179,1,0.35)] transition-all duration-300"
          >
            Book Now
          </Link>

          {/* Mobile hamburger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`md:hidden p-2 rounded-lg transition-colors ${transparent ? 'text-white' : 'text-[#111]'} hover:text-[#F5B301]`}
          >
            {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu — always solid white */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 ${isMobileMenuOpen ? 'max-h-80 opacity-100' : 'max-h-0 opacity-0'}`}
        style={{ background: '#ffffff', borderTop: '1px solid #EEEEEE' }}
      >
        <div className="px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`block text-sm font-medium py-2.5 px-4 rounded-xl transition-colors ${
                isActive(link.path)
                  ? 'bg-[#F5B301]/10 text-[#F5B301]'
                  : 'text-[#444] hover:bg-gray-50'
              }`}
            >
              {link.name}
            </Link>
          ))}
          <div className="pt-2">
            <Link
              to="/trips"
              className="block text-center bg-[#F5B301] text-[#111111] font-semibold py-2.5 rounded-full text-sm"
            >
              Book Now
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
