import { useState, useEffect } from 'react';
import { useParams, Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, AlertCircle } from 'lucide-react';

const Booking = () => {
  const { trekId } = useParams();
  const [searchParams] = useSearchParams();
  
  // Initialize form data with URL params if available
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', date: '', trekkers: 1,
    emergencyName: '', emergencyPhone: '', message: '', agreeTerms: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Set initial date and trekkers from URL params
  useEffect(() => {
    const dateParam = searchParams.get('date');
    const trekkersParam = searchParams.get('trekkers');
    
    setFormData(prev => ({
      ...prev,
      date: dateParam || prev.date,
      trekkers: trekkersParam ? parseInt(trekkersParam) : prev.trekkers
    }));
  }, [searchParams]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-dark-900 pt-28 flex items-center justify-center">
        <div className="bg-dark-800 rounded-2xl p-12 max-w-md text-center">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Booking Submitted!</h2>
          <p className="text-gray-400 mb-6">Thank you for your booking request. We'll contact you within 24 hours to confirm your trek.</p>
          <Link to="/treks" className="btn-primary inline-flex items-center gap-2">Browse More Treks</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 pt-28 pb-20">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-2">Book Your Trek</h1>
          <p className="text-gray-400 mb-8">Fill in the details below to reserve your adventure spot.</p>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="bg-dark-800 rounded-2xl p-8">
              <h2 className="text-xl font-semibold text-white mb-6">Personal Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">First Name *</label>
                  <input type="text" name="firstName" required value={formData.firstName} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Last Name *</label>
                  <input type="text" name="lastName" required value={formData.lastName} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Email *</label>
                  <input type="email" name="email" required value={formData.email} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Phone *</label>
                  <input type="tel" name="phone" required value={formData.phone} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
              </div>
            </div>

            <div className="bg-dark-800 rounded-2xl p-8">
              <h2 className="text-xl font-semibold text-white mb-6">Trek Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Preferred Date *</label>
                  <input type="date" name="date" required value={formData.date} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Number of Trekkers *</label>
                  <select name="trekkers" value={formData.trekkers} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500">
                    {[1,2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-dark-800 rounded-2xl p-8">
              <h2 className="text-xl font-semibold text-white mb-6">Emergency Contact</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Contact Name</label>
                  <input type="text" name="emergencyName" value={formData.emergencyName} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Contact Phone</label>
                  <input type="tel" name="emergencyPhone" value={formData.emergencyPhone} onChange={handleChange}
                    className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500" />
                </div>
              </div>
            </div>

            <div className="bg-dark-800 rounded-2xl p-8">
              <h2 className="text-xl font-semibold text-white mb-6">Additional Information</h2>
              <textarea name="message" value={formData.message} onChange={handleChange} rows={4}
                placeholder="Any special requirements or questions..."
                className="w-full bg-dark-700 border border-dark-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500 resize-none" />
            </div>

            <div className="flex items-start gap-3">
              <input type="checkbox" name="agreeTerms" checked={formData.agreeTerms} onChange={handleChange}
                className="w-5 h-5 mt-0.5 bg-dark-700 border-dark-600 rounded text-primary-500 focus:ring-primary-500" required />
              <label className="text-gray-400 text-sm">I agree to the <a href="#" className="text-primary-400 hover:underline">Terms of Service</a> and <a href="#" className="text-primary-400 hover:underline">Privacy Policy</a></label>
            </div>

            <button type="submit" disabled={isSubmitting}
              className="btn-primary w-full flex items-center justify-center gap-2 text-lg disabled:opacity-50">
              {isSubmitting ? 'Submitting...' : 'Submit Booking Request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Booking;
