import { Award, Users, Shield, Heart } from 'lucide-react';
import ServicePackages from '../components/ServicePackages';

const About = () => {
  const stats = [
    { value: '8+', label: 'Years Experience' },
    { value: '500+', label: 'Treks Completed' },
    { value: '10,000+', label: 'Happy Trekkers' },
    { value: '50+', label: 'Destinations' }
  ];

  const values = [
    { icon: Shield, title: 'Safety First', description: 'Your safety is our top priority. We maintain the highest safety standards with certified guides and comprehensive protocols.' },
    { icon: Award, title: 'Premium Quality', description: 'From accommodations to equipment, we ensure premium quality at every step of your journey.' },
    { icon: Users, title: 'Expert Team', description: 'Our team of certified mountaineers and local guides bring years of experience and deep regional knowledge.' },
    { icon: Heart, title: 'Sustainable Travel', description: 'We are committed to eco-friendly practices and supporting local communities in the mountains.' }
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FB]">
      {/* Hero Banner */}
      <div className="relative h-[45vh] min-h-[280px] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1600&q=80" alt="About" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-black/20" />
        <div className="absolute bottom-0 left-0 right-0 p-8 container-custom">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">About Trek Premi</h1>
          <p className="text-lg text-white/80 max-w-2xl">Your trusted partner for extraordinary mountain adventures since 2014</p>
        </div>
      </div>

      <div className="container-custom py-16">
        {/* Story + Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-16">
          <div>
            <span className="text-[#F5B301] font-medium mb-3 block text-sm uppercase tracking-wider">Our Story</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#111111] mb-5">Where Adventure Meets Excellence</h2>
            <p className="text-[#555555] leading-relaxed mb-4">
              Trek Premi was born from a simple belief: everyone deserves to experience the transformative power of mountain adventures. Founded by seasoned mountaineers, we've grown from a small group of passionate trekkers to one of India's most trusted adventure travel companies.
            </p>
            <p className="text-[#555555] leading-relaxed">
              Our mission is to create unforgettable journeys that push boundaries while maintaining the highest standards of safety, sustainability, and customer satisfaction.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 text-center border border-[#EEEEEE] shadow-sm">
                <div className="text-3xl font-bold text-[#F5B301] mb-1">{stat.value}</div>
                <div className="text-[#555555] text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Core Values */}
        <div className="mb-16">
          <div className="text-center mb-10">
            <span className="text-[#F5B301] font-medium mb-3 block text-sm uppercase tracking-wider">What We Stand For</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#111111]">Our Core Values</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {values.map((value, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 text-center border border-[#EEEEEE] shadow-sm hover:shadow-md transition-shadow">
                <div className="w-14 h-14 bg-[#F5B301]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-7 h-7 text-[#F5B301]" />
                </div>
                <h3 className="text-lg font-semibold text-[#111111] mb-2">{value.title}</h3>
                <p className="text-[#555555] text-sm leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Leadership */}
        <div className="bg-white rounded-3xl p-10 border border-[#EEEEEE] shadow-sm">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-[#111111] mb-3">Meet Our Leadership</h2>
            <p className="text-[#555555] max-w-xl mx-auto">The experienced team behind Trek Premi's success</p>
          </div>
          <div className="flex flex-col sm:flex-row justify-center gap-8 max-w-2xl mx-auto">
            {[
              { name: 'Akash Jalatkar', role: 'Founder', image: '/male.jpeg' },
              { name: 'Swapnali Annadate', role: 'Head Of Operations', image: '/female.png' },
            ].map((member, i) => (
              <div key={i} className="flex-1 bg-[#F8F9FB] rounded-2xl p-6 text-center border border-[#EEEEEE] hover:shadow-md transition-shadow">
                <div className="relative inline-block mb-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-28 h-28 rounded-full object-cover border-4 border-white shadow-lg"
                  />
                  <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-[#F5B301] rounded-full flex items-center justify-center shadow">
                    <span className="text-white text-xs font-bold">✓</span>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-[#111111] mb-1">{member.name}</h3>
                <span className="inline-block px-3 py-1 bg-[#F5B301]/10 text-[#F5B301] text-xs font-semibold rounded-full">{member.role}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <ServicePackages />
    </div>
  );
};

export default About;
