import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSubmitted(true);
  };

  const contactInfo = [
    { icon: MapPin, title: 'Address', details: ['Sai Vihar Colony, Near Sai Mandir,', 'MIDC, Ranjangaon Shenpunji, Waluj,', 'Wadgaon Kolhati, Maharashtra 431001'] },
    { icon: Phone, title: 'Call Us', details: ['Akash Jalatkar: +91 9156434444', 'Swapnali Annadate: +91 7758998055'] },
    { icon: Mail, title: 'Email Us', details: ['trekpremi01@gmail.com'] },
    { icon: Clock, title: 'Working Hours', details: ['Mon - Sat: 9AM - 8PM', 'Sunday: 10AM - 6PM'] }
  ];

  const inputClass = "w-full bg-[#F8F9FB] border border-[#EEEEEE] rounded-xl px-4 py-3 text-[#111111] placeholder-[#9CA3AF] focus:outline-none focus:border-[#F5B301] transition-colors";

  return (
    <div className="min-h-screen bg-[#F8F9FB]">
      {/* Header */}
      <div className="bg-white border-b border-[#EEEEEE] pt-20 pb-10">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-[#111111] mb-3">Get In Touch</h1>
          <p className="text-[#555555] max-w-xl mx-auto">Have questions? Send us a message and we'll respond as soon as possible.</p>
        </div>
      </div>

      <div className="container-custom py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            {isSubmitted ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-[#EEEEEE] shadow-sm">
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-[#111111] mb-3">Message Sent!</h2>
                <p className="text-[#555555]">Thank you for reaching out. We'll get back to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 border border-[#EEEEEE] shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="block text-[#555555] text-sm font-medium mb-2">Your Name *</label>
                    <input type="text" name="name" required value={formData.name} onChange={handleChange} className={inputClass} placeholder="John Doe" />
                  </div>
                  <div>
                    <label className="block text-[#555555] text-sm font-medium mb-2">Email *</label>
                    <input type="email" name="email" required value={formData.email} onChange={handleChange} className={inputClass} placeholder="john@example.com" />
                  </div>
                  <div>
                    <label className="block text-[#555555] text-sm font-medium mb-2">Phone</label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className={inputClass} placeholder="+91 98765 43210" />
                  </div>
                  <div>
                    <label className="block text-[#555555] text-sm font-medium mb-2">Subject *</label>
                    <input type="text" name="subject" required value={formData.subject} onChange={handleChange} className={inputClass} placeholder="Trip enquiry" />
                  </div>
                </div>
                <div className="mb-6">
                  <label className="block text-[#555555] text-sm font-medium mb-2">Message *</label>
                  <textarea name="message" required value={formData.message} onChange={handleChange} rows={5} className={`${inputClass} resize-none`} placeholder="Tell us about your travel plans..." />
                </div>
                <button type="submit" className="w-full flex items-center justify-center gap-2 bg-[#F5B301] text-[#111111] font-semibold py-3 rounded-xl hover:bg-[#E5A100] transition-colors">
                  Send Message <Send size={16} />
                </button>
              </form>
            )}
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            {contactInfo.map((info, i) => (
              <div key={i} className="bg-white rounded-2xl p-5 border border-[#EEEEEE] shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-[#F5B301]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <info.icon className="w-5 h-5 text-[#F5B301]" />
                  </div>
                  <div>
                    <h3 className="text-[#111111] font-semibold mb-1 text-sm">{info.title}</h3>
                    {info.details.map((detail, j) => (
                      <p key={j} className="text-[#555555] text-sm">{detail}</p>
                    ))}
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-[#F5B301] rounded-2xl p-5">
              <h3 className="text-[#111111] font-semibold mb-2">Follow Us</h3>
              <p className="text-[#111111]/70 text-sm mb-4">Stay connected for the latest updates and offers.</p>
              <div className="flex gap-2">
                {['F', 'I', 'T', 'Y'].map((s, i) => (
                  <a key={i} href="#" className="w-9 h-9 bg-[#111111]/10 rounded-lg flex items-center justify-center text-[#111111] font-semibold hover:bg-[#111111]/20 transition-colors text-sm">
                    {s}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
